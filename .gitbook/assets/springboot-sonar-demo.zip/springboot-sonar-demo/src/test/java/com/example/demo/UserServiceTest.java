package com.example.demo;

import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class UserServiceTest {

    @Test
    void testGetUserName() {
        UserRepository repo = new UserRepository();
        UserService service = new UserService(repo);

        assertEquals("John Doe", service.getUserName(1));
        assertEquals("Unknown", service.getUserName(5));
    }
}
