package com.example.demo.repository;

import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {

    public String findNameById(int id) {
        // Simple example – In real projects this calls DB
        if (id == 1) return "John Doe";
        return "Unknown";
    }
}
