package com.company.project.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;

@Slf4j
@RequiredArgsConstructor
@Service
public class ConsumerService {
	
	@JmsListener(destination = "${activemq.queue-name}", containerFactory = "queueListenerFactory")
    public void handleQueueMessage(String message) {
        log.info("Received message from queue: {}", message);
    }
    
    @JmsListener(destination = "${activemq.topic-name}", containerFactory = "topicListenerFactory")
    public void handleTopicMessage(String message) {
    	log.info("Received message from topic: {}", message);
    }
}
