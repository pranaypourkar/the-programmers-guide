package com.company.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.company.project.model.UserCredentials;

public interface UserRepository extends JpaRepository<UserCredentials, Long> {
    boolean existsByUsernameAndPassword(String username, String password);
}
