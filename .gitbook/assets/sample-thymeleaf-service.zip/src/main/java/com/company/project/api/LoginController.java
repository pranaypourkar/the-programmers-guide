package com.company.project.api;

import com.company.project.repository.UserRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/page")
public class LoginController {

    private final UserRepository userRepository;

    @GetMapping("/login")
    public ModelAndView showLoginPage() {
        return new ModelAndView("login/index");
    }

    @PostMapping("/login")
    public ModelAndView processLoginForm(@RequestParam("username") String username,
                                         @RequestParam("password") String password) {
        ModelAndView modelAndView;
        boolean userExists = userRepository.existsByUsernameAndPassword(username, password);
        if (userExists) {
            modelAndView = new ModelAndView("dashboard/index");
        } else {
            modelAndView = new ModelAndView("login/index");
            modelAndView.addObject("errorMessage", "Invalid username or password.");
        }
        return modelAndView;
    }
}
